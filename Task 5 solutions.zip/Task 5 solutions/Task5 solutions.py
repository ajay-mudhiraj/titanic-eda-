# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 07:10:30 2025

@author: Ajay
"""

#pip install pandas matplotlib seaborn jupyter

# Titanic EDA - Complete Plotting Script
# Builds and saves all 11 required graphs

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Set style and initialize output folder
sns.set_style('whitegrid')
os.makedirs('titanic_plots', exist_ok=True)

# Load and clean data
print("Loading Titanic dataset...")
try:
    df = sns.load_dataset('titanic')
    # Data cleaning
    df['age'].fillna(df['age'].median(), inplace=True)
    df['embarked'].fillna(df['embarked'].mode()[0], inplace=True)
    df.drop(['deck'], axis=1, inplace=True, errors='ignore')
    print("Data loaded and cleaned successfully!\n")
except Exception as e:
    print(f"Error loading data: {e}")
    exit()

# 1. Overall Data Distributions
print("1. Creating overall distributions plot...")
plt.figure(figsize=(15, 10))
df.hist(bins=30, layout=(3, 3))
plt.tight_layout()
plt.savefig('titanic_plots/1_overall_distributions.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/1_overall_distributions.png")

# 2. Correlation Heatmap
print("\n2. Creating correlation heatmap...")
plt.figure(figsize=(10, 6))
numeric_df = df.select_dtypes(include=['number'])
sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap', pad=20)
plt.savefig('titanic_plots/2_correlation_heatmap.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/2_correlation_heatmap.png")

# 3. Numerical Pairplot
print("\n3. Creating numerical pairplot...")
pairplot = sns.pairplot(df[['age', 'fare', 'pclass', 'survived']], hue='survived')
pairplot.fig.suptitle('Numerical Feature Relationships', y=1.02)
pairplot.savefig('titanic_plots/3_numerical_pairplot.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/3_numerical_pairplot.png")

# 4. Fare Transformation
print("\n4. Creating fare transformation comparison...")
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
df['fare'].hist(bins=30)
plt.title('Original Fare')
plt.subplot(1, 2, 2)
np.log1p(df['fare']).hist(bins=30)
plt.title('Log-Transformed Fare')
plt.suptitle('Fare Distribution Before/After Transformation')
plt.savefig('titanic_plots/4_fare_transformation.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/4_fare_transformation.png")

# 5. Multicollinearity Check
print("\n5. Creating multicollinearity check plot...")
plt.figure(figsize=(10, 6))
sns.boxplot(x='pclass', y='fare', data=df)
plt.title('Fare Distribution by Class (Multicollinearity Check)')
plt.savefig('titanic_plots/5_multicollinearity_check.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/5_multicollinearity_check.png")

# 6. Univariate Analysis
print("\n6. Creating univariate analysis plot...")
plt.figure(figsize=(8, 5))
sns.countplot(x='alone', data=df)
plt.title('Passengers Traveling Alone')
plt.savefig('titanic_plots/6_univariate_analysis.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/6_univariate_analysis.png")

# 7. Bivariate Analysis
print("\n7. Creating bivariate analysis plot...")
plt.figure(figsize=(10, 6))
sns.scatterplot(x='age', y='fare', data=df, alpha=0.6)
plt.title('Age vs Fare (Bivariate Analysis)')
plt.savefig('titanic_plots/7_bivariate_analysis.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/7_bivariate_analysis.png")

# 8. Multivariate Analysis
print("\n8. Creating multivariate analysis plot...")
plt.figure(figsize=(10, 6))
sns.scatterplot(x='age', y='fare', hue='survived', size='pclass', 
               sizes=(20, 200), alpha=0.7, data=df.sample(200))
plt.title('Age, Fare, Survival and Class (Multivariate)')
plt.savefig('titanic_plots/8_multivariate_analysis.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/8_multivariate_analysis.png")

# 9. Heatmap vs Scatterplot
print("\n9. Creating visualization comparison...")
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
sns.heatmap(df[['age', 'fare', 'pclass', 'survived']].corr(), annot=True)
plt.title('Heatmap')
plt.subplot(1, 2, 2)
sns.scatterplot(x='age', y='fare', hue='pclass', data=df.sample(100))
plt.title('Scatterplot')
plt.suptitle('Heatmap vs Scatterplot Comparison')
plt.savefig('titanic_plots/9_heatmap_vs_scatter.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/9_heatmap_vs_scatter.png")

# 10. Key Insight
print("\n10. Creating key insight plot...")
plt.figure(figsize=(10, 6))
sns.barplot(x='class', y='survived', hue='sex', data=df, ci=None)
plt.title('Survival Rate by Class and Gender (Key Insight)')
plt.savefig('titanic_plots/10_key_insight.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/10_key_insight.png")

# 11. Age by Survival
print("\n11. Creating age distribution plot...")
plt.figure(figsize=(10, 6))
sns.boxplot(x='survived', y='age', data=df)
plt.xticks([0, 1], ['Died', 'Survived'])
plt.title('Age Distribution by Survival Status')
plt.savefig('titanic_plots/11_age_by_survival.png', dpi=300, bbox_inches='tight')
plt.close()
print("Saved: titanic_plots/11_age_by_survival.png")

print("\nAll 11 plots saved successfully in 'titanic_plots' folder!")

import os
os.getcwd()
